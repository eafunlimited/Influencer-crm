export type EnumValues<Type> = Type[keyof Type];
